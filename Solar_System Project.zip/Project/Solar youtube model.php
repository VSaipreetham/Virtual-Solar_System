<html>
<head>
<title>Solar Youtube Model </title>
</head>

<frameset cols="10%,60%,30%" noresize>
<frame src="2.php" Scrolling="yes">
<frame src="3.php" Scrolling="auto">
<frame src="4.php" Scrolling="yes">



</frameset>
<body>

</body>


</html>
